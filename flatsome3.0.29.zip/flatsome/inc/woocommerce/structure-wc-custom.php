<?php
/*
    Engine Room for creating Custom WooCommerce Pages with Shortcodes
*/

// require get_template_directory() . '/inc/woocommerce/custom/product.php';
