<?php

/* HEADER TEMPLATES */

// Product Headers
function flatsome_product_header(){
    if(is_product() && flatsome_option('product_header')){
       return wc_get_template_part('single-product/headers/header-product', flatsome_option('product_header'));
    }
}
add_action('flatsome_after_header','flatsome_product_header');


// Add Transparent Header To Cateogry if Set
function flatsome_product_header_classes($classes){

    // Add transparent header to product page if set.
    if(is_product() && flatsome_option('product_header_transparent')){
         $classes[] = 'transparent has-transparent nav-dark toggle-nav-dark';
    }

    return $classes;
}

add_filter('flatsome_header_class','flatsome_product_header_classes', 10);


/* BREADCRUMBS */

// Add Breadcrunmbs To Description if no custom page header is set
function flatsome_woocommerce_product_breadcrumb() {
  if(!flatsome_option('product_header')){
    woocommerce_breadcrumb();
  }
}
add_action( 'woocommerce_single_product_summary', 'flatsome_woocommerce_product_breadcrumb',  0 );


// Add Breadcrumbs to Featured Headers if set
function flatsome_product_page_breadcrumbs(){
  ?>
    <div class="is-<?php echo flatsome_option('breadcrumb_size'); ?>">
        <?php woocommerce_breadcrumb(); ?>
    </div>
  <?php
}
add_action('flatsome_product_title','flatsome_product_page_breadcrumbs',20);


// Move Page title up if featured header is set
function flatsome_product_page_title(){
  if(flatsome_option('product_header') !== 'featured-center') return;
  ?>
  <h1 itemprop="name" class="product-title entry-title">
    <?php the_title(); ?>
  </h1>
  <?php
  remove_action('woocommerce_single_product_summary','woocommerce_template_single_title', 5);
}
add_action('flatsome_product_title','flatsome_product_page_title', 10);


/* Add Next/Prev Nav to Product Image  */
function flatsome_product_title_next_prev(){
   echo flatsome_product_next_prev_nav();
}
add_action('flatsome_product_title_tools','flatsome_product_title_next_prev', 20);


function flatsome_product_mobile_next_prev_nav(){
   if(!flatsome_option('product_header')){
        flatsome_product_next_prev_nav('show-for-medium');
   }
}
add_action('woocommerce_single_product_summary','flatsome_product_mobile_next_prev_nav', 7);


/* Add Next/Prev Nav to Product Sidebar  */
function flatsome_product_nav_sidebar(){
   if(!flatsome_option('product_header') && flatsome_option('product_layout') !== 'left-sidebar-full' && flatsome_option('product_layout') !== 'left-sidebar'){
    echo '<div class="hide-for-off-canvas" style="width:100%">';
      flatsome_product_next_prev_nav('nav-right text-right');
    echo '</div>';
   }
}
add_action('flatsome_before_product_sidebar','flatsome_product_nav_sidebar', 0);



function flatsome_product_next_prev_nav($class = ''){
      echo '<ul class="next-prev-thumbs is-small '.$class.'">';
      flatsome_next_post_link_product();
      flatsome_previous_post_link_product();
      flatsome_open_product_sidebar_lightbox();
      echo '</ul>';
}


function flatsome_next_post_link_product() {
    global $post;
    $next_post = get_next_post(true,'','product_cat');
    if ( is_a( $next_post , 'WP_Post' ) ) { ?>
       <li class="prod-dropdown has-dropdown">
             <a href="<?php echo get_the_permalink( $next_post->ID ); ?>"  rel="next" class="button icon is-outline circle">
                <?php echo get_flatsome_icon('icon-angle-left'); ?>
            </a>
            <div class="nav-dropdown">
              <a title="<?php echo get_the_title( $next_post->ID ); ?>" href="<?php echo get_the_permalink( $next_post->ID ); ?>">
              <?php echo get_the_post_thumbnail($next_post->ID, apply_filters( 'single_product_small_thumbnail_size', 'shop_thumbnail' )) ?></a>
            </div>
        </li>
    <?php }
}

function flatsome_previous_post_link_product() {
    global $post;
    $prev_post = get_previous_post(true,'','product_cat');
    if ( is_a( $prev_post , 'WP_Post' ) ) { ?>
       <li class="prod-dropdown has-dropdown">
             <a href="<?php echo get_the_permalink( $prev_post->ID ); ?>" rel="next" class="button icon is-outline circle">
                <?php echo get_flatsome_icon('icon-angle-right'); ?>
            </a>
            <div class="nav-dropdown">
                <a title="<?php echo get_the_title( $prev_post->ID ); ?>" href="<?php echo get_the_permalink( $prev_post->ID ); ?>">
                <?php echo get_the_post_thumbnail($prev_post->ID, apply_filters( 'single_product_small_thumbnail_size', 'shop_thumbnail' )) ?></a>
            </div>
        </li>
    <?php }
}

function flatsome_open_product_sidebar_lightbox() {
    if(!flatsome_option('product_offcanvas_sidebar')) return; ?>
    <li class="product-page-filtering show-for-medium text-center">
      <a href="#product-sidebar"
        class="off-canvas-overlay filter-button button is-outline icon is-round mb-0"
        data-open="#product-sidebar" 
        data-pos="left"
        data-visible-after="true"
        title="<?php echo __( 'Categories', 'woocommerce' ); ?>"
        data-color="light">
          <i class="icon-menu"></i>
        </a>
    </li><!-- Category filtering -->
<?php }